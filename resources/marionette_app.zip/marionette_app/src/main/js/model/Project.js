define(['backbone'], function(Backbone){
    var Project = Backbone.Model.extend({});
    return Project;
});